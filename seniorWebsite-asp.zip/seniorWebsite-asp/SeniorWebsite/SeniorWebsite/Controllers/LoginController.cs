﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using SeniorWebsite.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;


namespace SeniorWebsite.Controllers
{
    public class LoginController : Controller
    {
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(string username, string password)
        {
            // Create an instance of HttpClient
            using (var httpClient = new HttpClient())
            {
                // Set the URL of the PHP file that will handle the login
                string phpUrl = "http://no.mygamesonline.org/Login.php";

                // Prepare the form data to be sent
                var formData = new List<KeyValuePair<string, string>>
     {
         new KeyValuePair<string, string>("username", username),
         new KeyValuePair<string, string>("password", password)
     };

                HttpResponseMessage httpResponse = await httpClient.PostAsync(phpUrl, new FormUrlEncodedContent(formData));

                // Read the response from the PHP file
                string responseContent = await httpResponse.Content.ReadAsStringAsync();

                // Deserialize the JSON response
                dynamic jsonResponse = JsonConvert.DeserializeObject(responseContent);
                // Access the response properties based on the JSON structure
                string status = jsonResponse.status;
                string message = jsonResponse.message;

                // Handle the response
                if (status == "success")
                {
                    Administrator administrator = new Administrator
                    {
                        UserName = username,
                        Password = password
                    };

                    HttpContext.Session.SetString("Username", username); // Set a session variable
                                                                         // Create claims for the authenticated user
                    var claims = new List<Claim>
                       {
                           new Claim(ClaimTypes.Name, username),
    
                         };

                    // Create an identity for the user
                    var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                    var principal = new ClaimsPrincipal(identity);
                    // Sign the user in using cookie authentication
                    await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

                    return View("SelectToUpdate", administrator);
                }
                else
                {
                    // Login failed, show an error message
                    ViewBag.ErrorMessage = "Invalid username or password";
                    return View("Login");
                }
            }
        }
        [Authorize]
        public IActionResult SelectToUpdate(Administrator administrator)
        {
            return View(administrator);
        }
        [HttpGet]
        [Authorize]
        public IActionResult AddNewSensor()
        {
            return View();  
        }
        [HttpPost]
        public async Task<IActionResult> AddNewSensor(string sensorName, string normalValue, string description)
        {
            try
            {
                // string normal= normalValue;
                // Create an HttpClient instance
                HttpClient client = new HttpClient();

                // Set the URL of the PHP script
                string url = "http://no.mygamesonline.org/Update.php";

                // Create the request content with the insert query
                string insertQuery = $"INSERT INTO Sensor (Name, Normal_Value, Description) VALUES ('{sensorName}', '{normalValue}', '{description}')";
                StringContent content = new StringContent(insertQuery);

                // Send the POST request
                HttpResponseMessage response = await client.PostAsync(url, content);
                // Check if the request was successful
                if (response.IsSuccessStatusCode)
                {
                    // Read the response content
                    string result = await response.Content.ReadAsStringAsync();

                    // Check the result
                    if (result == "ok")
                    {
                        ViewBag.Message = string.Format("The sensor has been added successfully ");
                        // Query executed successfully
                        return View();
                    }
                    else
                    {
                        // Handle other response cases
                        return BadRequest("Unexpected response: " + result);
                    }
                }
                else
                {
                    // Handle request failure
                    return StatusCode((int)response.StatusCode, "Request failed with status code: " + response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                // Handle any exceptions
                return StatusCode(500, "Exception occurred: " + ex.Message);
            }
        }
        [HttpGet]
        [Authorize]
        public IActionResult UpdateNormalValue()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> UpdateNormalValue(string sensor, string updateValue)
        {
            try
            {
                // Create an HttpClient instance
                HttpClient client = new HttpClient();

                // Set the URL of the PHP script
                string url = "http://no.mygamesonline.org/Update.php";

                // Create the request content with the insert query
                string updateQuery = $"UPDATE Sensor SET Normal_Value = '{updateValue}' WHERE Name = '{sensor}'";
                StringContent content = new StringContent(updateQuery);

                // Send the POST request
                HttpResponseMessage response = await client.PostAsync(url, content);

                // Check if the request was successful
                if (response.IsSuccessStatusCode)
                {
                    // Read the response content
                    string result = await response.Content.ReadAsStringAsync();
                    // Check the result
                    if (result == "ok")
                    {
                        ViewBag.Message = string.Format("The sensor normal value has been updated successfully ");
                        // Query executed successfully
                        return View();
                    }
                    else
                    {
                        // Handle other response cases
                        return BadRequest("Unexpected response: " + result);
                    }
                }
                else
                {
                    // Handle request failure
                    return StatusCode((int)response.StatusCode, "Request failed with status code: " + response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                // Handle any exceptions
                return StatusCode(500, "Exception occurred: " + ex.Message);
            }
        }
        [HttpGet]
        public async Task<IActionResult> Logout()
        {
            // Sign the user out using cookie authentication
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login");
        }
        


    }
}
