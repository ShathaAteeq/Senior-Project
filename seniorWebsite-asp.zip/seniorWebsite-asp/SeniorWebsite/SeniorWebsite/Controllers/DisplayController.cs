﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Reflection;
using System.Threading.Tasks;
using System;
using SeniorWebsite.Models;
using System.Linq;
using Newtonsoft.Json.Linq;
using System.Net;
using System.Xml.Linq;
using System.Drawing;
using System.Runtime.Intrinsics.X86;

namespace SeniorWebsite.Controllers
{
    public class DisplayController : Controller
    {
        [HttpGet]
        public IActionResult Display( )
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Display(string cities, DateTime startDate, DateTime endDate, string Gas)
        {
            Form form = new Form { city = cities, startdate = startDate, enddate = endDate, gas = Gas };
            string formattedStartDate = startDate.ToString("yyyy-MM-dd");
            string formattedEndDate = endDate.ToString("yyyy-MM-dd");
            double maxLatitude, maxLongitude, minLatitude, minLongitude;
            int ID;
           
            switch (cities)
            {
                case "Jenin":
                    maxLatitude = 32.513613;
                    maxLongitude = 35.423149;
                    minLatitude = 32.327667;
                    minLongitude = 35.128664;
                    
                    break;

                case "Nablus":
                    maxLatitude = 32.2500;
                    maxLongitude = 35.2854;
                    minLatitude = 32.2000;
                    minLongitude = 35.2154;
                    

                    break;

                case "Ramallah":
                    maxLatitude = 31.9522;
                    maxLongitude = 35.2842;
                    minLatitude = 31.8933;
                    minLongitude = 35.1816;
                    
                    break;

                case "Hebron":
                    maxLatitude = 31.5543;
                    maxLongitude = 35.1325;
                    minLatitude = 31.4841;
                    minLongitude = 35.0583;
              
                    break;

                case "Tulkarem":
                    maxLatitude = 32.3194;
                    maxLongitude = 35.0142;
                    minLatitude = 32.2914;
                    minLongitude = 35.0019;
                    break;

                default:
                    maxLatitude = 32.51313;
                    maxLongitude = 35.423149;
                    minLatitude = 32.327667;
                    minLongitude = 35.128664;
                   
                    break;

            }
           
            switch (Gas)
            {
                case "Co":
                    ID = 1;
                    break;

                case "Air quality(ammonia,Benzene)":
                    ID = 2;
                    break;

                case "PM2.5":
                    ID = 3;
                    break;

                case "PM10":
                    ID = 4;
                    break;
                case "Co2":
                    ID = 5;
                    break;
                default:
                    ID = 0;
                    break;
            }
            City city = new City { MaxLatitude = maxLatitude, MaxLongitude = maxLongitude, MinLatitude = minLatitude, MinLongitude = minLongitude };

            string query = $"SELECT Longitude,Latitude,Sensor_Value,Sensor_id FROM Measurements WHERE Longitude BETWEEN {minLongitude} AND {maxLongitude} AND Latitude BETWEEN {minLatitude} AND {maxLatitude} AND Date BETWEEN '{formattedStartDate}' AND '{formattedEndDate}' AND Sensor_id={ID}";
            // Create an instance of HttpClient
            using (HttpClient client = new HttpClient())
            {
                // Send the GET request to the PHP file
                HttpResponseMessage response = await client.GetAsync($"http://no.mygamesonline.org/VisualQuery.php?query={Uri.EscapeDataString(query)}");

                // Check if the request was successful

                if (response.IsSuccessStatusCode)
                {
                    string xmlString = await response.Content.ReadAsStringAsync();

                    XDocument xmlDoc = XDocument.Parse(xmlString);
                    var measurements = xmlDoc.Descendants("record")
                        .Select(m => new Measurements
                        {
                            Longitude = (double)m.Element("Longitude"),
                            Latitude = (double)m.Element("Latitude"),
                            Sensor_Value = (float)m.Element("Sensor_Value"),
                            Sensor_id = (int)m.Element("Sensor_id")
                        })
                        .ToArray();
                    var halfKilometer = 0.00452214494; // Half a kilometer in latitude/longitude difference
                    var halfkilometer_long = 0.5 / (111.320 * Math.Cos(maxLatitude));
                    var firstSquareCenter = new Square
                    {
                        Center_Lat = maxLatitude - halfKilometer,
                        Center_Lon = minLongitude + halfkilometer_long
                    };

                    // Divide the rectangle into small squares
                    var squares = new List<Square>();
                    var currentCenter = firstSquareCenter;
                    while (currentCenter.Center_Lat >= minLatitude)
                    {
                        var lat = currentCenter.Center_Lat;
                        for (var lng = currentCenter.Center_Lon; lng <= maxLongitude; lng += (1.0 / (111.320 * Math.Cos(lat))))
                        {
                           float avg = 0;
                            int count = 0;
                            float sum = 0;
                            foreach (var item in measurements)
                            {
                                if ((item.Latitude <= (lat + 0.00452214494)) && (item.Latitude >= (lat - 0.00452214494)) && (item.Longitude >= (lng - 0.5 / (111.320 * Math.Cos(lat)))) && (item.Longitude <= (lng + 0.5 / (111.320 * Math.Cos(lat)))))
                                {
                                    sum += item.Sensor_Value;
                                    count++;
                                }
                                if (sum == 0)
                                {
                                    avg = 0;
                                }
                                avg = sum / count;
                            }
                            // dist = CalculateDistance(lat, lng, 32.508185, 35.310711);
                            var square = new Square { Center_Lat = lat, Center_Lon = lng, Average = avg };
                            squares.Add(square);
                        }
                        currentCenter.Center_Lat -= 0.00904428989; // Move 1 kilometer down
                    }

                    MyViewModel viewModel = new MyViewModel
                    {
                        Squares = squares,
                        GasName = Gas,
                        cityboundary = city,
                        userform = form
                    };


                    // Return the view
                    return View(viewModel);
                }

                else
                {
                    // Handle unsuccessful request
                    return View(null);
                }

            }
        }
       

    }
}


