﻿namespace SeniorWebsite.Models
{
    public class City
    {
        public double MaxLatitude { get; set; }
        public double MaxLongitude { get; set; }
        public double MinLatitude { get; set; }
        public double MinLongitude { get; set; }
    }
}
