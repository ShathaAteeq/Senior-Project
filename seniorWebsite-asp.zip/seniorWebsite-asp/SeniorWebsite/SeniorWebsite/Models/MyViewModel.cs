﻿using System.Collections.Generic;

namespace SeniorWebsite.Models
{
    public class MyViewModel
    {
        public List<Square> Squares { get; set; }
        public string GasName { get; set; }
        public City cityboundary { get; set; }
        public Form userform { get; set; }

    }
}
