﻿namespace SeniorWebsite.Models
{
    public class Measurements
    {
        public double Longitude { get; set; }

        public double Latitude { get; set; }

        public float Sensor_Value { get; set; }

        public int Sensor_id { get; set; }
    }
}
