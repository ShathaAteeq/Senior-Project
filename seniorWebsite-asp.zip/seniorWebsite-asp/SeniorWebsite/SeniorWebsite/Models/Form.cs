﻿using System;

namespace SeniorWebsite.Models
{
    public class Form
    {
        public string city { get; set; }
        public DateTime startdate { get; set; }
        public DateTime enddate { get; set; }
        public string gas { get; set; }

    }
}
