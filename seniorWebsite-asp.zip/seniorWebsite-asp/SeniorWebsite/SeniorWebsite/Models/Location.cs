﻿namespace SeniorWebsite.Models
{
    public class Location
    {
        public int ID { get; set; }
        public decimal Longitude { get; set; }
        public decimal Latitude { get; set; }
    }
}
