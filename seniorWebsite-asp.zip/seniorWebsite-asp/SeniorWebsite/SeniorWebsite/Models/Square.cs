﻿namespace SeniorWebsite.Models
{
    public class Square
    {
        public double Center_Lat { get; set; }
        public double Center_Lon { get; set; }
        public float Average { get; set; }
    }
}
