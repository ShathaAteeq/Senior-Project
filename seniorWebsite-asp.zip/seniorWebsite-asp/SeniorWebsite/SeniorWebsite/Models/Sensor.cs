﻿namespace SeniorWebsite.Models
{
    public class Sensor
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public float Normal_Value { get; set; }
        public string Description { get; set; }

        public override string ToString()
        {
            return $"Id: {ID}, Name: {Name}, Value: {Normal_Value},$Description: {Description}";
        }
    }
}
